/* Below is my Class definition of my personal information*/
export class Personal{
  fName: string;
  lName: string;
  studNum: number;
  username: string;
  pic: string;
}